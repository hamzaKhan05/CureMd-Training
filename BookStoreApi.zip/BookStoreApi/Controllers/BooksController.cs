using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using BookStoreApi.Models;
using System;

[ApiController]
[Route("api/[controller]")]
public class BooksController : ControllerBase
{
    private static readonly List<Book> Books = new List<Book>
    {
        new Book { Id = 1, Title = "Abdullah", Author = "Hashim Nadeem", Description = "Abdullah: Novel by Hashim Nadeem", ImageUrl = "././images/book-cover.jpg" },
        new Book { Id = 2, Title = "Humsafar", Author = "Bano Apa", Description = "Humsafar: Novel by Bano Apa", ImageUrl = "././images/humsafar.jpg" }
    };

    [HttpGet]
    public ActionResult<IEnumerable<Book>> Get()
    {
        return Ok(Books);
    }

    [HttpGet("{id}")]
    public ActionResult<Book> Get(int id)
    {
        var book = Books.FirstOrDefault(b => b.Id == id);
        if (book == null)
            return NotFound();

        return Ok(book);
    }

    [HttpPost]
    public ActionResult Post([FromBody] Book book)
    {
        book.Id = Books.Max(b => b.Id) + 1; 
        Books.Add(book);
        return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
    }

    [HttpPut("{id}")]
    public ActionResult Put(int id, [FromBody] Book book)
    {
        var existingBook = Books.FirstOrDefault(b => b.Id == id);
        if (existingBook == null)
            return NotFound();

        existingBook.Title = book.Title;
        existingBook.Author = book.Author;
        existingBook.Description = book.Description;
        existingBook.ImageUrl = book.ImageUrl;

        return NoContent();
    }

    [HttpDelete("{id}")]
    public ActionResult Delete(int id)
    {
        var book = Books.FirstOrDefault(b => b.Id == id);
        if (book == null)
            return NotFound();

        Books.Remove(book);
        return NoContent();
    }

    [HttpGet("author/{author}")]
    public ActionResult<IEnumerable<Book>> GetByAuthor(string author)
    {
        var booksByAuthor = Books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();
        if (!booksByAuthor.Any())
            return NotFound();

        return Ok(booksByAuthor);
    }
}
