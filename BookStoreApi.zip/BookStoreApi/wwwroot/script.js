$(document).ready(function() {
    function fetchAllBooks() {
        $.ajax({
            type: 'GET',
            url: 'https://localhost:5001/api/books',
            success: function(data) {
                displayBooks(data);
            },
            error: function() {
                alert("Error fetching books");
            }
        });
    }

    function displayBooks(books) {
        $('#mybooks').empty();
        books.forEach(function(book) {
            $('#mybooks').append(`
                <div class="book">
                    <h3>${book.title}</h3>
                    <p>${book.author}</p>
                    <p>${book.description}</p>
                    <img src="${book.imageUrl}" alt="${book.title}">
                </div>
            `);
        });
    }

    fetchAllBooks();

    $('#bookSearch').on('input', function() {
        let query = $(this).val();
        if (query) {
            $.ajax({
                type: 'GET',
                url: `https://localhost:5001/api/books/${query}`,
                success: function(data) {
                    displayBooks([data]);
                },
                error: function() {
                    alert("Book not found");
                }
            });
        } else {
            fetchAllBooks();
        }
    });

    $('#addBookForm').submit(function(event) {
        event.preventDefault();
        let newBook = {
            title: $('#title').val(),
            author: $('#author').val(),
            description: $('#description').val(),
            imageUrl: $('#imageUrl').val()
        };
        $.ajax({
            type: 'POST',
            url: 'https://localhost:5001/api/books',
            contentType: 'application/json',
            data: JSON.stringify(newBook),
            success: function() {
                alert("Book added successfully");
                fetchAllBooks();
                $('#addBookForm')[0].reset();
            },
            error: function() {
                alert("Error adding book");
            }
        });
    });

    $('#loadMore').click(function() {
        fetchAllBooks();
    });
});
